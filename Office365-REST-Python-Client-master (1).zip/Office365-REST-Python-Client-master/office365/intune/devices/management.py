from office365.entity import Entity


class DeviceManagement(Entity):
    pass
