from office365.entity import Entity


class PlannerPlanDetails(Entity):
    """
    The plannerPlanDetails resource represents the additional information about a plan.
    Each plan object has a details object.
    """
