from office365.entity import Entity


class WorkbookTableColumn(Entity):
    """Represents a column in a table."""
    pass
