from office365.entity import Entity


class WorkbookTableRow(Entity):
    """Represents a row in a table."""
    pass
