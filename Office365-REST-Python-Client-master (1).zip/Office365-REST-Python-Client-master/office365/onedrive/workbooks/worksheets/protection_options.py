from office365.runtime.client_value import ClientValue


class WorkbookWorksheetProtectionOptions(ClientValue):
    """Represents the protection of a sheet object."""
