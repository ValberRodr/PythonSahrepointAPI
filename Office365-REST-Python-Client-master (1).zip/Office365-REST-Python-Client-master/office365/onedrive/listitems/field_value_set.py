from office365.base_item import BaseItem


class FieldValueSet(BaseItem):
    """Represents the column values in a listItem resource."""
