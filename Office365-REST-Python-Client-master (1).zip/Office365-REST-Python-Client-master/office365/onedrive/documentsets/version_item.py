from office365.runtime.client_value import ClientValue


class DocumentSetVersionItem(ClientValue):
    """
    Represents an item that is a part of a captured documentSetVersion.
    """
