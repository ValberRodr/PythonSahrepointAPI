from office365.onedrive.versions.list_item import ListItemVersion


class DocumentSetVersion(ListItemVersion):
    """Represents the version of a document set item in a list."""
