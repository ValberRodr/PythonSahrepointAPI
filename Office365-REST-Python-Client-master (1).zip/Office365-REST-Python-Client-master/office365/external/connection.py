from office365.entity import Entity


class ExternalConnection(Entity):
    """A logical container to add content from an external source into Microsoft Graph."""
