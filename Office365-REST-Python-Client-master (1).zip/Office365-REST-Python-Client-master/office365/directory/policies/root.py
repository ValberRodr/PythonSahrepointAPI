from office365.entity import Entity


class PolicyRoot(Entity):
    """Resource type exposing navigation properties for the policies singleton."""
