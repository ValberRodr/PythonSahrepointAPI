from office365.runtime.client_value import ClientValue


class ConvertIdResult(ClientValue):
    """The result of an ID format conversion performed by the translateExchangeIds function."""
