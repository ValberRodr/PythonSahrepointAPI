from office365.outlook.mail.attachments.attachment import Attachment


class ItemAttachment(Attachment):
    pass
