from office365.runtime.client_value import ClientValue


class RecurrencePattern(ClientValue):
    """Describes the frequency by which a recurring event repeats."""
    pass
