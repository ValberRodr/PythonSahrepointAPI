class BodyType:
    def __init__(self):
        pass

    html = "html"
    text = "text"
