from office365.runtime.client_value import ClientValue


class LocationConstraint(ClientValue):
    """The conditions stated by a client for the location of a meeting."""
    pass
