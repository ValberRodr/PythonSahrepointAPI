from office365.runtime.client_value import ClientValue


class WorkingHours(ClientValue):
    pass
