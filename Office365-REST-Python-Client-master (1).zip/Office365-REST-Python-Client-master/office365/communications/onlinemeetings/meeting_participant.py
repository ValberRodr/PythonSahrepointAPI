from office365.runtime.client_value import ClientValue


class MeetingParticipant(ClientValue):
    """Participants in a meeting."""
    pass
