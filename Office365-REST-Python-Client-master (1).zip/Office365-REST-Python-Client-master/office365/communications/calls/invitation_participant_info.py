from office365.runtime.client_value import ClientValue


class InvitationParticipantInfo(ClientValue):
    """This resource is used to represent the entity that is being invited to a group call."""
    pass
