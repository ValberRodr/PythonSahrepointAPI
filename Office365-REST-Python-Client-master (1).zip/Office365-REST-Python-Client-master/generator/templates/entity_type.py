from office365.runtime.client_object import ClientObject


class EntityType(ClientObject):
    pass
