import ast


class PropertyBuilder(ast.NodeTransformer):
    pass
