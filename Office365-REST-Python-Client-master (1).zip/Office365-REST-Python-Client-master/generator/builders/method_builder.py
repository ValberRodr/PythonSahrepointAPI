import ast


class MethodBuilder(ast.NodeTransformer):
    pass
